$(document).ready(function() {

  generateQuote();



  $(document).keypress(function(event) {
    if (event.which == 32) {

      event.preventDefault();
      generateQuote();

    }
  });


  $("p").click(function(){
    generateQuote();
  });





  function generateQuote() {

    var q = {
      subject: getFrom(subjects),

      adverb: "",
      verb: getFrom(verbs),
      verbAdd: "",

      objectPrev: "the",
      adjective: "",
      object: getFrom(objects),
      objectAdd: ""
    }



    if(q.verb==""){
      q.verb="see";
    }

    if (q.subject == "He" || q.subject == "She" || q.subject == "It") {
      q.verbAdd = "s";

      if(q.verb[q.verb.length-1]=="s"||q.verb[q.verb.length-1]=="h"){
        q.verbAdd = "es";

      }
    }


    if (Math.random() > 0.75) {
      q.subject = upperCaseFirst(getFrom(namesFirst));
      q.verbAdd = "s";
    }


    if (Math.random() > 0.66) {
      q.adverb = getFrom(adverbs);
    }


    if (Math.random() > 0.66) {
      q.adjective = getFrom(adjectives);
    }

    if (Math.random() > 0.80) {
      q.objectAdd = "s";
    }


    console.log(q);


    quoteString = q.subject + " " + q.adverb + " " + q.verb + q.verbAdd +
      " " + q.objectPrev + " " + q.adjective + " " + q.object + q.objectAdd;
    authorString = " - " + getFrom(namesFirst) + " " + getFrom(namesSecond);


    $("h1").html(quoteString);
    $("h2").html(authorString);

  }



  function getFrom(list) {
    return list[getRandom(0, list.length - 1)]
  }


  function getRandom(max, min) {
    return Math.round(Math.random() * (max - min) + min)
  }

  function upperCaseFirst(string) {
    var newString = "";
    string = string.toLowerCase().split("");
    for (var i = 0; i < string.length; i++) {
      if (i == 0) {
        newString = newString + string[i].toUpperCase();
      } else {
        newString = newString + string[i];
      }
    }
    return newString
  }

});
