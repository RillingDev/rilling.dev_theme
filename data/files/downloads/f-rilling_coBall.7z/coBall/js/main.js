$(document).ready(function() {

  var counter = 10,
    turns = 10,
    score = 0;
  moveBack(turns);




  $("button").click(function() {

    if ($(this).attr("id") === "buttonUpLeft") {
      aniBall(0, 0, "ball", 200, true);
    }
    if ($(this).attr("id") === "buttonUpRight") {
      aniBall(255, 0, "ball", 200, true);
    }
    if ($(this).attr("id") === "buttonDownLeft") {
      aniBall(0, 255, "ball", 200, true);
    }
    if ($(this).attr("id") === "buttonDownRight") {
      aniBall(255, 255, "ball", 200, true);
    }

    counter--;
    modScore("turns", counter, "-1");

  });


  $("#compTurns").focusout(function() {
    turns = $("#compTurns").val();
    reDraw();
  });





  function checkWin() {
    if (collision()) {
      turnsLeft = counter;
      $("#goal").stop();
      counter = turns;
      modScore("turns", counter, "");
      score++;
      modScore("score", score, "+1");
      reDraw();
    } else {
      if (counter == 0) {
        $("#goal").stop();
        counter = turns;
        modScore("turns", counter, "");
        score = 0;
        modScore("score", score, "X");
        reDraw();
      }
    }

  }


  function aniBall(x, y, obj, time, check) {

    $("#" + obj).animate({
      left: getHalf("left", x, obj),
      top: getHalf("top", y, obj)
    }, time, function() {
      if (check) {
        checkWin()
      };
    });

  }


  function getHalf(direction, baseVal, obj) {

    var amount = makeNum($("#" + obj).css(direction)) + (baseVal - makeNum($("#" + obj).css(direction)) / 2);

    if (amount > 450) {
      amount = 450;
    }
    if (amount < 0) {
      amount = 0;
    }
    return amount;
  }



  function reDraw() {
    $("turns").html(counter);
    if (makeNum($("#goal").css("height")) > 10) {
      $("#goal").css("width", (75 - score * 5) + "px");
      $("#goal").css("height", (75 - score * 5) + "px");
    }

    while (collision()) {
      moveBack(turns);
    }

  }



  function moveBack(v) {
    while (collision()) {

      for (var i = 0; i < v; i++) {
        $("#goal").stop();
        var rand = Math.floor(Math.random() * 4);
        var x = 0,
          y = 0;

        if (rand == 1 || rand == 3) {
          x = 200;
        }
        if (rand == 2 || rand == 3) {
          y = 200;
        }
        aniBall(x, y, "goal", 0, false);
      }

    }

  }


  function modScore(obj, val, text) {

    $("#" + obj).html(val);
    $("#" + obj).append("<b class='modInfo'>" + text + "</b>");
    $(".modInfo").animate({
      top: "-=50",
      opacity: 0
    }, 750,function(){
      $(".modInfo").remove();
    });


  }

  function collision() {
    var x1 = $("#ball").offset().left;
    var y1 = $("#ball").offset().top;
    var h1 = $("#ball").outerHeight(true);
    var w1 = $("#ball").outerWidth(true);
    var b1 = y1 + h1;
    var r1 = x1 + w1;
    var x2 = $("#goal").offset().left;
    var y2 = $("#goal").offset().top;
    var h2 = $("#goal").outerHeight(true);
    var w2 = $("#goal").outerWidth(true);
    var b2 = y2 + h2;
    var r2 = x2 + w2;

    if (b1 < y2 || y1 > b2 || r1 < x2 || x1 > r2) return false;
    return true;
  }


  function makeNum(string) {
    return parseInt(string.replace("px", ""))
  }

});
