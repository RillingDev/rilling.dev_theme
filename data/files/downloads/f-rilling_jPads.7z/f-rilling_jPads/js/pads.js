var doLog = true,
  isLocal = true,
  currentTimerLength = 5000,
  rule,
  powerUp = false;

$(document).ready(function() {

  /*#########Setup##########*/
  var score = 0,
    scoreMax = 0,
    padString = "#pad1",
    oldString = "#pad1",
    lieString = "#pad2",
    oldLie = "#pad2",
    colorPri = "#333333",
    colorSec = "#F39C12";

  $("#volumeSlider").slider({
    value: 50
  });

  if (isLocal === false) {

    if ($.cookie("score") !== null) {
      score = $.cookie("score");
      $("#score").html(score);
    }

    if ($.cookie("scoreMax") !== null) {
      scoreMax = $.cookie("scoreMax");
      $("#scoreMax").html(scoreMax);
    }

    if ($.cookie("activePad") !== null) {
      genPad($.cookie("activePad"));
    }

    if ($.cookie("volume") !== null) {
      $("#volumeSlider").slider({
        value: $.cookie("volume")
      });
    }

    if ($.cookie("colorPri") !== null) {
      colorPri = $.cookie("colorPri");
    }

    if ($.cookie("colorSec") !== null) {
      colorSec = $.cookie("colorSec");
    }

  }

  /*#########Event Handlers############*/
  $('.pad').click(function() {
    if (doLog) {
      console.log("issued via mouse: #" + this.id);
    }
    checkPad($(this));
  });

  $(document).keypress(function(event) {

    if ($('input').is(':focus')) {
      if (doLog) {
        console.log("blocked input");
      }
    } else {
      if ((event.which >= 49) && (event.which <= 57)) {

        if (doLog) {
          console.log("issued via key: " + event.which);
        }

        if (event.which === 55) {
          pressedKey = 1;
        } else if (event.which === 56) {
          pressedKey = 2;
        } else if (event.which === 57) {
          pressedKey = 3;
        } else if (event.which === 52) {
          pressedKey = 4;
        } else if (event.which === 53) {
          pressedKey = 5;
        } else if (event.which === 54) {
          pressedKey = 6;
        } else if (event.which === 49) {
          pressedKey = 7;
        } else if (event.which === 50) {
          pressedKey = 8;
        } else {
          pressedKey = 9;
        }

        pressedPad = "#pad" + pressedKey;

        if (doLog) {
          console.log("interpreted as: " + pressedPad);
        }

        checkPad($(pressedPad));
      }
    }
  });

  $("#toggleSettings").click(function() {
    if ($("#toggleSettings").hasClass("opened")) {
      $("#toggleSettings").removeClass("opened");
      $("#settings").css("display", "none");
    } else {
      $("#toggleSettings").addClass("opened");
      $("#settings").css("display", "block");
    }

  });


  $("#applyCustomColors").click(function() {
    colorPri = ($(".customColorPri").val()).toUpperCase();
    colorSec = ($(".customColorSec").val()).toUpperCase();

    if (/(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(colorPri)) {
      $.cookie("colorPri", colorPri, {
        expires: 1000
      });
      if (doLog) {
        console.log("changing Pri Color to " + colorPri);
      }

      $(".customColorPri").css("border", "2px solid " + colorPri);
      $("button,.ui-slider,progress").css("background-color", colorPri);
      $("h1,h2,i").css("color", colorPri);

      var style = "progress::-webkit-progress-bar{background-color:" + colorPri + ";}";
      document.styleSheets[2].insertRule(style, 0);
      console.log('new rule is: ' + style);

    } else {
      $(".customColorPri").css("border", "2px solid #CC4747");
    }

    if (/(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(colorSec)) {
      $.cookie("colorSec", colorSec, {
        expires: 1000
      });
      if (doLog) {
        console.log("changing Sec Color to " + colorSec);
      }

      $(".customColorSec").css("border", "2px solid " + colorPri);
      $(".active,.ui-slider-handle,progress::-webkit-progress-value").css("background-color", colorSec);
      $("span").css("color", colorSec);

      var style = "progress::-webkit-progress-value{background-color:" + colorSec + ";}";
      document.styleSheets[2].insertRule(style, 0);
      console.log('new rule is: ' + style);

    } else {
      $(".customColorSec").css("border", "2px solid #CC4747");
    }
  });


  $("#reset").click(function() {
    if (doLog) {
      console.log("reset");
    }
    score = 0;
    $.cookie("score", 0, {
      expires: 1000
    });
    scoreMax = 0;
    $.cookie("scoreMax", 0, {
      expires: 1000
    });
    $("#score").html("0");
    $("#scoreMax").html("0");
    $("#volumeSlider").slider({
      value: 50
    });
    doPad(1);

  });

  /*#########Functions############*/
  function checkPad(padId) {
    if (padId.hasClass("powerUp")) {
      if (doLog) {
        console.log("activated powerup");
      }
      checkPowerups(padId);
    } else if (padId.hasClass("active")) {
      if (doLog) {
        console.log("is true");
      }
      truePad(padId);
    } else {
      if (doLog) {
        console.log("is false");
      }
      falsePad();
    }

    setTimer();
  }

  function truePad() {
    score++;
    $("#score").html(score);
    $.cookie("score", score, {
      expires: 1000
    });
    if (score > scoreMax) {
      scoreMax = score;
      $("#scoreMax").html(scoreMax);
      $.cookie("scoreMax", scoreMax, {
        expires: 1000
      });
    }
    playSound("assets/win.mp3");
    genPad();


    currentTimerLength = Math.floor((currentTimerLength / 100) * 90);

    if (doLog) {
      console.log("Timer Value: " + getScore() + " --> " + currentTimerLength);
    }
  }

  function falsePad() {
    score = 0;
    $("#score").html(score);
    $.cookie("score", 0, {
      expires: 1000
    });
    playSound("assets/loose.mp3");
    genPad();
    currentTimerLength = 5000;
  }

  function genPad() {
    while (padString === oldString) {
      padString = "#pad" + (Math.floor(Math.random() * 9) + 1);
    }

    $("button").removeClass("active");
    $(padString).addClass("active");

    $("button").css("background-color", colorPri);
    $(".active").css("background-color", colorSec);

    oldString = padString;
    $.cookie("activePad", padString, {
      expires: 1000
    });
	if (document.URL.indexOf("#noahmode") < 0) {
	console.log("#noahmode1");
    if (score >= 40) {
      doLiePad(8);
    } else if (score >= 35) {
      doLiePad(7);
    } else if (score >= 30) {
      doLiePad(6);
    } else if (score >= 25) {
      doLiePad(5);
    } else if (score >= 20) {
      doLiePad(4);
    } else if (score >= 15) {
      doLiePad(3);
    } else if (score >= 10) {
      doLiePad(2);
    } else if (score >= 5) {
      doLiePad(1);
    }
	}
  }

  function doPad(padId) {
    padString = "#pad" + padId;

    $("button").removeClass("active");
    $(padString).addClass("active");

    $("button").css("background-color", colorPri);
    $(".active").css("background-color", colorSec);

    oldString = padString;
    $.cookie("activePad", padString, {
      expires: 1000
    });
  }

  function doLiePad(amount) {

    for (var i = 1; i <= amount; i++) {
      while (lieString === oldLie || lieString === padString) {
        lieString = "#pad" + (Math.floor(Math.random() * 9) + 1);
      }


      $("button").removeClass("lie" + i);
      $(lieString).addClass("lie" + i);

      deletePowerups();
      tryPowerups();

      if (document.URL.indexOf("#noahmode") > 0) {

        if (i === 1) {
          console.log("#noahmode2");
          $(".lie" + i).css("background-color", "#e16a5e");
        } else if (i === 2) {
          $(".lie" + i).css("background-color", "#2fa5f5");
        } else if (i === 3) {
          $(".lie" + i).css("background-color", "#828282");
        } else if (i === 4) {
          $(".lie" + i).css("background-color", "#009999");
        } else if (i === 5) {
          $(".lie" + i).css("background-color", "#8053ae");
        } else if (i === 6) {
          $(".lie" + i).css("background-color", "#af68cc");
        } else if (i === 7) {
          $(".lie" + i).css("background-color", "#1abc9c");
        } else if (i === 8) {
          $(".lie" + i).css("background-color", "#c0392b");
        }

      } else {

        if (i === 1) {
          $(".lie" + i).css("background-color", "#e16a5e");
        } else if (i === 2) {
          $(".lie" + i).css("background-color", "#2fa5f5");
        } else if (i === 3) {
          $(".lie" + i).css("background-color", "#94d436");
        } else if (i === 4) {
          $(".lie" + i).css("background-color", "#009999");
        } else if (i === 5) {
          $(".lie" + i).css("background-color", "#8053ae");
        } else if (i === 6) {
          $(".lie" + i).css("background-color", "#af68cc");
        } else if (i === 7) {
          $(".lie" + i).css("background-color", "#1abc9c");
        } else if (i === 8) {
          $(".lie" + i).css("background-color", "#c0392b");
        }

      }

      oldLie = lieString;
      $.cookie("liePad" + i, lieString, {
        expires: 1000
      });

    }
  }

  function setTimer() {

    $("#timer").stop();
    $("#timer").val(1);

    $("#timer").animate({
      value: "0.0"
    }, currentTimerLength, function() {
      console.log("time over!");
      currentTimerLength = 5000;
      $("#score").html("0");
      score = 0;
      $.cookie("score", 0, {
        expires: 1000
      });
      falsePad();
    });

  }


  function playSound(url) {
    sound = new Audio(url);
    sound.volume = ($("#volumeSlider").slider("value")) / 100;
    sound.play();
    $.cookie("volume", $("#volumeSlider").slider("value"), {
      expires: 1000
    });
  }


  function tryPowerups() {

    var powerUp = Math.floor(Math.random() * 255);
    if (powerUp >= 200) {

      $(lieString).addClass("powerUp");

      if (powerUp > 254) {
        $(lieString).addClass("points3");
        $(lieString).html("<i class='fa fa-bomb'></i>");
      } else if (powerUp > 250) {
        $(lieString).addClass("points2");
        $(lieString).html("<i class='fa fa-bolt'></i>");
      } else if (powerUp > 225) {
        $(lieString).addClass("points1");
        $(lieString).html("<i class='fa fa-star'></i>");
      } else if (powerUp > 200) {
        $(lieString).addClass("time");
        $(lieString).html("<i class='fa fa-clock-o'></i>");
      }
      powerUp = true;
    }
  }

  function deletePowerups() {
    $("button").removeClass("powerUp");
    $("button").removeClass("time");
    $("button").removeClass("points1");
    $("button").removeClass("points2");
    $("button").removeClass("points3");
    $("button").html("");
    powerUp = false;
  }

  function checkPowerups(padId) {

    if (padId.hasClass("time")) {
      $("#timer").stop();
      currentTimerLength = Math.floor((currentTimerLength / 100) * 150);
	  if(currentTimerLength>5000){currentTimerLength=5000;}
    } else if (padId.hasClass("points1")) {
      score = getScore() + 10;
      $("#score").html(score);
      $.cookie("score", score, {
        expires: 1000
      });
    } else if (padId.hasClass("points2")) {
      score = getScore() + 25;
      $("#score").html(score);
      $.cookie("score", score, {
        expires: 1000
      });
    } else if (padId.hasClass("points3")) {
      score = getScore() + 100;
      $("#score").html(score);
      $.cookie("score", score, {
        expires: 1000
      });
    }

    playSound("assets/power.mp3");
    deletePowerups();
  }

  function getScore() {
    return tempScore = parseInt($("#score").html());
  }


});
