 <?php
$room=$_GET["r"];
   include("connect.php");
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}

    $data = "SELECT * FROM (SELECT * FROM `room".$room."` ORDER BY id DESC LIMIT 10) g ORDER BY g.Time ASC ";
		$result = mysqli_query($con, $data);
			while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
                echo "<div class='chatPost'><p class='stringSender'>";
                echo $row['Username'];
                echo "</p><p class='stringTime'>[";
                $row['Time'] = substr($row['Time'], 11, strpos($row['Time'], ' '));
                echo $row['Time'];
                echo "]: </p>";
                echo "<p class='stringText'>";
                echo $row['Content'];
                echo "</p></div>";
            }
        echo "<a name='end'>&nbsp;</a>";
				mysqli_free_result($result);
				mysqli_close($con);
			?>
