<?php
//Connect to the Database (change the values to your mysql sever)
$con=mysqli_connect("localhost","root","","rchat");
?>
