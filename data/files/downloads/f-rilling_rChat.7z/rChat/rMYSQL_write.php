<?php
	include("connect.php");
	$room=$_GET["room"];
	$name=mysqli_real_escape_string($con,$_GET["name"]);
	$cont=mysqli_real_escape_string($con,$_GET["content"]);
	$time=substr(str_replace("+",":",str_replace("T"," ",date(DATE_ATOM))),0,18);


	// Check connection
	if (mysqli_connect_errno())
	  {
	  echo "Failed to connect to MySQL: " . mysqli_connect_error();
	  }
	  
	
	

	//Writing

		//Console output
		if($name=="Console"){
			$sql="INSERT INTO room$room (Time, Username, Content)
			VALUES
			('$time','<b>Console</b>','$cont')";
			}


		//Normal Output
		else{
			$sql="INSERT INTO room$room (Time, Username, Content)
			VALUES
			('$time','$name','$cont')";
			}


		//Error Message
		if (!mysqli_query($con,$sql)){
			die('Error: ' . mysqli_error($con));
			}


		echo "'$cont' added to room$room!";

	mysqli_close($con);
?>
