<html>

<head>
  <title>rChat Client</title>
  <meta charset="utf-8">
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width">
  <meta name="HandheldFriendly" content="True">
  <meta name="description" content="rChat Client">
  <meta name="author" content="Felix Rilling">

  <!--<link rel="stylesheet" href="http://necolas.github.io/normalize.css/3.0.1/normalize.css" type="text/css" media="screen"/>-->
  <link rel="stylesheet" href="css/normalize.min.css" type="text/css" media="screen" />
  <link rel="stylesheet" href="css/main.css" type="text/css" media="screen" />
  <script src="js/jquery-2.1.1.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/jquery.cookie.js"></script>
  <script src="js/randomFunctions.js"></script>
  <script src="js/rChat.js"></script>
  <link rel="shortcut icon" type="image/x-icon" href="css/favicon.ico" />
</head>

<body>
  <?php
  //Check if tables need to be created
  include("connect.php");
  if(!mysqli_query($con,"DESCRIBE `room1`")) {

	echo "Creating...";

	  $sql1="CREATE TABLE IF NOT EXISTS `room1` (
			  `id` int(4) NOT NULL AUTO_INCREMENT,
			  `Time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
			  `Username` text COLLATE latin1_german2_ci NOT NULL,
			  `Content` text COLLATE latin1_german2_ci NOT NULL,
			  PRIMARY KEY (`id`)
			) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=4593 ;";
		if (!mysqli_query($con,$sql1)){
			die('Error: ' . mysqli_error($con));
			}

		$sql2="CREATE TABLE IF NOT EXISTS `room3` (
			  `id` int(4) NOT NULL AUTO_INCREMENT,
			  `Time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
			  `Username` text COLLATE latin1_german2_ci NOT NULL,
			  `Content` text COLLATE latin1_german2_ci NOT NULL,
			  PRIMARY KEY (`id`)
			) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=4593 ;";
		if (!mysqli_query($con,$sql2)){
			die('Error: ' . mysqli_error($con));
			}

		$sql3="CREATE TABLE IF NOT EXISTS `room2` (
			`id` int(4) NOT NULL AUTO_INCREMENT,
			`Time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
			`Username` text COLLATE latin1_german2_ci NOT NULL,
			`Content` text COLLATE latin1_german2_ci NOT NULL,
			PRIMARY KEY (`id`)
			) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=4593 ;";
		if (!mysqli_query($con,$sql3)){
			die('Error: ' . mysqli_error($con));
			}

	  }
  ?>
  <div id="linkBack" style="position:absolute;right:0px;bottom:0px;background-color:#333;margin:0;width:65px;">
    <a href="http://f-rilling.com/projects/" style="font-size:14px;text-decoration:none;color:#fff;padding:0 0 0 5px;">Go Back</a>
  </div>
  <div id="container">

    <!--Main Stuff-->
    <div id="about">
      <h1>rChat</h1>
      <p class="version">Version: 1.1.1 | &copy; 2014 Felix Rilling
      </p>
    </div>



    <div id="settings">
      <input id='userName' type='text' placeholder='Someone' value='Anonym' maxlength='10'>
      <select id="userRoom" name="room">

        <?php $room=$_GET[ "r"]; if($room=="1" ){echo "<option value='1' selected='selected'>Room 1</option>";}else{echo "<option value='1'>Room 1</option>";} if($room=="2" ){echo "<option value='2' selected='selected'>Room 2</option>";}else{echo
        "<option value='2'>Room 2</option>";} if($room=="3" ){echo "<option value='3' selected='selected'>Room 3</option>";}else{echo "<option value='3'>Room 3</option>";} ?>

      </select>
    </div>



    <div id="chat">

      <div id='chatOutput' width='518px' height='324px'></div>

      <input id="chatInput" type="text" placeholder="Input Text here" maxlength="36">
      <button id="chatSend">Send</button>
    </div>



  </div>
</body>

</html>
