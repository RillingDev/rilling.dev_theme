//Copyright 2014 Felix Rilling - Libary for rChat
//##########################-Setup-#################################

$(document).ready(function() {


  var currentText = " ",
    currentName = "Anonym",
    oldName = "Anonym",
    currentRoom = "1",
    update = setInterval(function(){updateChat();},100);




  if ($.cookie("Name") != undefined) {
    currentName = $.cookie("Name");
    currentRoom = $.cookie("Room");

    oldName = currentName;
    $("#userName").val(currentName);
    $("userRoom").val("Room " + currentRoom);
  } else {
    $.cookie("Name", "Anonym", {
      expires: 500
    });
    $.cookie("Room", "1", {
      expires: 500
    });
  }

  sendString("Console", "<i>" + currentName + "</i> entered", currentRoom);


  //##########################Event Handlers##############################
  $("#userName").focusout(function() {

    currentName = stringSafe($("#userName").val(), 2);
    $.cookie("Name", currentName, {
      expires: 500
    });
    sendString("Console", "<i>" + currentName + "</i> is <i>" + oldName + "</i>s new Username!", currentRoom);

    setTimeout(function() {
      updateChat(currentRoom);
    }, 250);
    oldUsername = currentName;
  });


  $("#userRoom").change(function() {
    sendString("Console", "<i>" + currentName + "</i> left", currentRoom);

    currentRoom = $("#userRoom").val().replace("Room ", "");
    $.cookie("Room", currentRoom, {
      expires: 500
    });
    sendString("Console", "<i>" + currentName + "</i> entered", currentRoom);

    $("#chatInput").val("");

    window.location.href = "rChatClient.php?r=" + currentRoom;
  });


  $("#chatSend").click(function() {
    sendChat();
  });


  $(document).keypress(function(event) {
    if (event.which == 13) {
      sendChat();
    }
  });
  //##########################Functions##############################
  function sendChat() {
    //Sends this shiat
		currentText = stringSafe($("#chatInput").val(), 2);

    if ((currentText !== "") && (currentText !== " ")) {

      sendString(currentName, stringSafe(currentText, 2), currentRoom);
      $("#chatInput").val("");
    }
  }

  function sendString(Name, Text, Room) {
    //xml send to php
    var url = decodeURI("rMYSQL_write.php?room=" + Room + "&name=" + Name + "&content=" + Text);
    $.post(url);
  }

  function updateChat(Room) {
    //refreshing iframe
    $.get( "rChatFrame.php?r=1", function( data ) {
      $( "#chatOutput" ).html( data );
    })
  }


});
