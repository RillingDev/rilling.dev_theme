//Copyright 2014 Felix Rilling - rLib 0.1.1

//#########################-Input-###############################
getMySQLDatetime = function(outputType) {
  //outputs mysql datetime format date

  var currentTime = new Date();

  if (outputType == null) {
    currentTime =
      currentTime.getUTCFullYear() + '-' +
      ('00' + (currentTime.getUTCMonth() + 1)).slice(-2) + '-' +
      ('00' + currentTime.getUTCDate()).slice(-2) + ' ' +
      ('00' + currentTime.getUTCHours()).slice(-2) + ':' +
      ('00' + currentTime.getUTCMinutes()).slice(-2) + ':' +
      ('00' + currentTime.getUTCSeconds()).slice(-2);
  }

  if (outputType == "date") {
    currentTime =
      currentTime.getUTCFullYear() + '-' +
      ('00' + (currentTime.getUTCMonth() + 1)).slice(-2) + '-' +
      ('00' + currentTime.getUTCDate()).slice(-2);
  }

  if (outputType == "time") {
    currentTime =
      currentTime.getUTCHours() + ':' +
      ('00' + currentTime.getUTCMinutes()).slice(-2) + ':' +
      ('00' + currentTime.getUTCSeconds()).slice(-2);
  }


  return currentTime;
};





getIP = function() {
  if (window.XMLHttpRequest) xmlhttp = new XMLHttpRequest();
  else xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");

  xmlhttp.open("GET", "http://api.hostip.info/get_html.php", false);
  xmlhttp.send();

  hostipInfo = xmlhttp.responseText.split("\n");

  for (i = 0; hostipInfo.length >= i; i++) {
    ipAddress = hostipInfo[i].split(":");
    if (ipAddress[0] == "IP") return encodeURI(ipAddress[1].replaceAll(".", "%"));
  }

  return false;
}


getRandom = function(max, min) {
  return Math.round(Math.random() * (max - min) + min)
}

//#########################-Cookies-##############################
cookieWrite = function(cookieName, cookieValue) {
  //Writes Cookie

  document.cookie = cookieName + '=' + cookieValue +
    ';expires=Thu, 01 Jan 2099 00:00:00 GMT' +
    '; path=/';


  return true;
};



cookieRead = function(cookieIndex) {
  //Reads Cookies

  var splittingCookie = document.cookie.split(';');

  if (splittingCookie[cookieIndex] !== null) {

    splittingCookie[cookieIndex] = splittingCookie[cookieIndex].replace(/^.+=/, "");


    return splittingCookie[cookieIndex];
  } else {
    return false;
  }
};



//#########################-DataConvert-#############################
convertDecToBin = function(dec) {
  //Converts dec to bin

  bin = parseInt(dec, 10).toString(2);

  return bin;
};



convertBinToDec = function(bin) {
  //Converts bin to dec

  dec = parseInt(bin, 2);

  return dec;
};


convertToggleBoolean = function(boolean) {
  if (boolean == true) {
    return false
  }
  if (boolean == false) {
    return true
  }
}

convertBooleanToInt = function(boolean) {
  if (boolean) {
    return 1
  } else {
    return 0
  }
}


//#########################-String-##############################
stringSafe = function(string, mode) {
  //Cleans Strings for dangerous code

  var safeString = string;

  if (mode === 1) {
    safeString = string.replace(/&/g, "&amp;").replace(/>/g, "&gt;").replace(/</g, "&lt;").replace(/"/g, ";").replace(/'/g, ";");
  }
  if (mode === 2) {
    safeString = string.replace(/([*;<>${}|\[\]\/\\])/g, "<b>[i]</b>");
  }
  if (safeString === "") {
    safeString = " ";
  }

  return safeString;
};



stringDetectLinks = function(noLinkString, possibleLinks) {
  //Detetcts links and converts them
  if (noLinkString.indexOf("www.")) {
    var linkURL = noLinkString.substring(noLinkString.indexOf("www."));
    var linkString = "<a href=http://" + linkURL + ">" + linkURL + "</a>";


    return linkString;
  } else {
    return false;
  }

};


stringCreateLink = function(url, linkTitle) {
  //Detetcts links and converts them
  if (linkTitle != undefined) {
    return "<a href='" + url + "'>" + linkTitle + "</a>";
  } else {
    return "<a href='" + url + "'>" + url + "</a>";
  }

};


stringReplaceAll = function(string, find, replace) {
  var newString = "";
  string = string.split("");
  for (var i = 0; i < string.length; i++) {
    if (string[i] === find) {
      newString = newString + replace;
    } else {
      newString = newString + string[i];
    }
  }
  return newString
}


stringModifyAtPos = function(string, replacer, pos) {
  var newString = "";
  string = string.split("");
  for (var i = 0; i < string.length; i++) {
    if (i === pos) {
      newString = newString + replacer;
    } else {
      newString = newString + string[i];
    }
  }
  return newString
}

//#########################-Colors-##############################
colorHextoRgb = function(hex) {
  //Converts hex to rgb

  var r = hex >> 16;
  g = hex >> 8 & 0xFF;
  b = hex & 0xFF;
  hex2 = r + "," + g + "," + b;

  return hex2;
};



colorRgbToHex = function(rgb) {
  //Converts rgb to hex

  rgb = rgb.split(',');
  r = rgb[0];
  g = rgb[1];
  b = rgb[2];

  bin = r << 16 | g << 8 | b;

  return (function(h) {
    return new Array[7 - h.length].join("0") + h;
  })(bin.toString(16).toUpperCase());

  return hex;
};



colorModifyBrightnessOfHex = function(hex, modificationFactor) {
  //modifys Brightness of hex

  hex2 = modifyBrightnessOfRgb(convertHextoRgb(hex), modificationFactor);

  return hex2;
};



colorModifyBrightnessOfRgb = function(rgb, modificationFactor) {
  //modifys Brightness of rgb

  var rgb2 = rgb.split(',');
  if ((r = parseInt(rgb2[0]) + Math.round(2.55 * modificationFactor)) < 0) {
    r = 0;
  }
  if ((g = parseInt(rgb2[1]) + Math.round(2.55 * modificationFactor)) < 0) {
    g = 0;
  }
  if ((b = parseInt(rgb2[2]) + Math.round(2.55 * modificationFactor)) < 0) {
    b = 0;
  }

  if (r > 255) {
    r = 255;
  }
  if (g > 255) {
    g = 255;
  }
  if (b > 255) {
    b = 255;
  }

  rgb2 = r + "," + g + "," + b;

  return rgb2;
};


//#########################-Output-##############################

outputPlaySound = function(url, volume) {
  sound = new Audio(url);
  if (volume != undefined) {
    sound.volume = volume;
  }
  sound.play();
}


outputWriteXml = function(string) {
  xmlhttp = new XMLHttpRequest();
  xmlhttp.open("GET", string);
  xmlhttp.send();
}
