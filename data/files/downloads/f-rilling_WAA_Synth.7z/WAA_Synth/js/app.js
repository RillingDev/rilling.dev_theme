$(document).ready(function() {
  //Setup
  var synth = new(window.AudioContext || window.webkitAudioContext)();


  var osc1 = synth.createOscillator();
  var gainNode1 = synth.createGain();
  osc1.connect(gainNode1);
  gainNode1.connect(synth.destination);
  osc1.type = 'sine';
  osc1.frequency.value = 440;
  osc1.frequency.add = 0;
  gainNode1.gain.value = 0;
  gainNode1.Gain = 0.5;

  var osc2 = synth.createOscillator();
  var gainNode2 = synth.createGain();
  osc2.connect(gainNode2);
  gainNode2.connect(synth.destination);
  osc2.type = 'sine';
  osc2.frequency.value = 440;
  osc2.frequency.add = 0;
  gainNode2.gain.value = 0;
  gainNode2.Gain = 0.5;

  var osc3 = synth.createOscillator();
  var gainNode3 = synth.createGain();
  osc3.connect(gainNode3);
  gainNode3.connect(synth.destination);
  osc3.type = 'sine';
  osc3.frequency.value = 440;
  osc3.frequency.add = 0;
  gainNode3.gain.value = 0;
  gainNode3.Gain = 0.5;

  var master={
    gain:20,
    pan:0
  };

  osc1.start();
  osc2.start();
  osc3.start();


  $(".WaveformKnob").knob({
    'step': 1,
    'class': 'waveform',
    'change': function(v) {
      routeSettings(this.x, this.y, v, this)
    }
  });
  $(".VolumeKnob,.DetuneKnob,.TuneKnob,.PanKnob").knob({
    'change': function(v) {
      routeSettings(this.x, this.y, v, this)
    }
  });




  //Event Handlers
  $(".key").mouseenter(function() {
    startPlaying($(this).attr("id"));
  });

  $(".key").mouseleave(function() {
    stopPlaying();
  });



  $(document).keydown(function(event) {
    //console.log(event.which);
    if ($("." + event.which).length) {
      $("." + event.which).addClass("hover");
      startPlaying($("." + event.which).attr("id"));
    }
  });

  $(document).keyup(function() {
    $(".key").removeClass("hover");
    stopPlaying();
  });





  //Functions
  function startPlaying(freq) {
    gainNode1.gain.value = gainNode1.Gain/100*master.gain;
    gainNode2.gain.value = gainNode2.Gain/100*master.gain;
    gainNode3.gain.value = gainNode3.Gain/100*master.gain;

    osc1.frequency.value = freq + osc1.frequency.add;
    osc2.frequency.value = freq + osc2.frequency.add;
    osc3.frequency.value = freq + osc3.frequency.add;

  }

  function stopPlaying() {
    gainNode1.gain.value = 0;
    gainNode2.gain.value = 0;
    gainNode3.gain.value = 0;
  }




  function routeSettings(x, y, v, $object) {
    //console.log(x+" "+y+" "+v);
    var type,
      osc;
    if (x <= 500) {
      type = 1;
    } else if (x <= 600) {
      type = 2;
    } else if (x <= 700) {
      type = 4;
    } else if (x <= 800) {
      type = 3;
    }

    if (y <= 250) {
      osc = 1;
    } else if (y <= 350) {
      osc = 2;
    } else if (y <= 450) {
      osc = 3;
    }
    setSettings(type, osc, v, $object);
  }

  function setSettings(type, osc, v, $object) {
    //console.log(type + " " + osc + " " + v + " ");
    if (type == 1) {
      if (v > 12.5 && v <= 37.5) {
        v = "sine";
      } else if (v > 37.5 && v <= 62.5) {
        v = "square";
      } else if (v > 62.5 && v <= 87.5) {
        v = "saw";
      } else {
        v = "triangle";
      }

      eval("osc" + osc + ".type=v;");
      //console.log("osc" + osc + ".type=" + v);
    } else if (type == 2) {
      v = (v / 3.333) / 100;
      eval("gainNode" + osc + ".Gain=v;");
      //console.log("gainNode" + osc + ".Gain=" + v);
    } else if (type == 3) {
      eval("osc" + osc + ".frequency.add=v;");
      //console.log("osc" + osc + ".frequency.add=" + v);
    } else if (type == 4) {
      v = (v / 12) * 100;
      eval("osc" + osc + ".detune.value=v;");
      //console.log("osc" + osc + ".detune.value=" + v);
    }
  }

  function pan(range) {
    var xDeg = parseInt(range.value);
    var zDeg = xDeg + 90;
    if (zDeg > 90) {
      zDeg = 180 - zDeg;
    }
    var x = Math.sin(xDeg * (Math.PI / 180));
    var z = Math.sin(zDeg * (Math.PI / 180));
    p.setPosition(x, 0, z);
  }


});
